# Variables

Run `npm install` to install dependencies.

Implement all the problems in the __problems/__ folder.

Run `npm test` to test all your problems.

To test a specific problem, run `npm test test/<name-of-problem-file>-spec.js`.
For example, if the problem file is called `hello-world.js`, then run
`npm test test/hello-world-spec.js` to test it.
npm test test/02-add-lib-spec.js
npm test test/01-variables-spec.js